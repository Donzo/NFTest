			<a href='/'><div class="header">
				<div class="header-logo-img">
					<img src="/images/old-pc-transparent-bg.png" style='height: 100%; width: 100%; object-fit: contain'/>
					<!--img src="/images/old-pc-transparent-bg.png"/-->
				</div>
				<div class="header-txt-img">
					<img src="/images/nftest-logo-words.png"/>
				</div>
			</div></a>