<div id='footer-link-container'>
					<div class='footer-item' id='my-tests-link'>
						<a href='https://nftest.net/my-tests'>
							My Tests
						</a>
					</div>
					<div class='footer-item hide-on-phone' id='twitter-button'>
						<a target='_blank' href='https://twitter.com/NFTestDotNet'>
							Twitter
						</a>
					</div>
					<div class='footer-item hide-on-phone' id='contact-button'>
						<a target='_blank' href='mailto:nftest.net@protonmail.com'>
							Contact
						</a>
					</div>
					<div class='footer-item' id='contracts-link'>
						<a href='https://nftest.net/links'>
							Useful Links
						</a>
					</div>
					<div class='footer-item' id='contracts-link'>
						<a href='https://nftest.net/terms-of-use.txt'>
							Terms of Use
						</a>
					</div>
					<div class='footer-item hide-on-phone' id='contracts-link'>
						<a href='https://nftest.net/privacy-policy.txt'>
							Privacy Policy
						</a>
					</div>
				</div>